import React from 'react';
import ReactDOM from 'react-dom';

function Home() {
    return (
        <div className="row justify-content-center">
            <div className="col-md-12">
                <div className="card">
                    <div className="card-header">This Home</div>
                </div>
            </div>
        </div>
    );
}

export default Home;
