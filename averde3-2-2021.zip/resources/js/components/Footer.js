import React from 'react';
import ReactDOM from 'react-dom';

function Footer() {
    return (
        <div className="row justify-content-center">
            <div className="col-md-12">
                <div className="card">
                    <div className="card-header">This Footer</div>
                </div>
            </div>
        </div>
    );
}

export default Footer;
